#include <jukebox/ui/indexes_popup.hpp>

#include <Geode/utils/function.hpp>
#include <vector>

#include <Geode/cocos/base_nodes/CCNode.h>
#include <Geode/cocos/sprite_nodes/CCSprite.h>
#include <Geode/binding/CCMenuItemSpriteExtra.hpp>
#include <Geode/ui/Layout.hpp>
#include <Geode/ui/Popup.hpp>
#include <Geode/ui/SimpleAxisLayout.hpp>

#include <jukebox/nong/index.hpp>
#include <jukebox/ui/list/index_cell.hpp>

using namespace geode::prelude;

namespace jukebox {

using namespace jukebox::index;

bool IndexesPopup::init(std::vector<IndexSource> indexes,
                        geode::Function<void(std::vector<IndexSource>)> setIndexesCallback) {
    const CCSize size = this->getPopupSize();
    if (!Popup::init(size.width, size.height)) {
        return false;
    }

    m_indexes = std::move(indexes);
    m_setIndexesCallback = std::move(setIndexesCallback);

    this->createList();

    const auto spr = CCSprite::createWithSpriteFrameName("GJ_plusBtn_001.png");
    spr->setScale(0.7f);
    const auto addBtn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(IndexesPopup::onAdd));
    addBtn->setAnchorPoint({0.5f, 0.5f});
    const auto menu = CCMenu::create();
    menu->addChild(addBtn);
    menu->setZOrder(1);
    m_mainLayer->addChildAtPosition(menu, Anchor::BottomRight,
                                    {-5.f - addBtn->getContentWidth() / 2.f, 8.f + addBtn->getContentHeight() / 2.f});

    return true;
}

void IndexesPopup::onClose(CCObject* sender) {
    m_setIndexesCallback(m_indexes);
    Popup::onClose(sender);
}

void IndexesPopup::onAdd(CCObject*) {
    m_indexes.push_back({
        .m_url = "",
        .m_userAdded = true,
        .m_enabled = true,
    });
    this->createList();
}

IndexesPopup* IndexesPopup::create(std::vector<IndexSource> indexes,
                                   geode::Function<void(std::vector<IndexSource>)> setIndexesCallback) {
    auto ret = new IndexesPopup();
    if (ret->init(std::move(indexes), std::move(setIndexesCallback))) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

CCSize IndexesPopup::getPopupSize() { return {320.f, 240.f}; }

void IndexesPopup::createList() {
    auto size = this->m_mainLayer->getContentSize();

    constexpr static float s_padding = 5.f;

    if (m_list) {
        m_list->removeFromParent();
    }

    m_list = ScrollLayer::create({size.width - s_padding * 2, size.height - s_padding * 2 - 4.f});
    m_list->setPosition({s_padding, s_padding + 2.f});

    for (int i = 0; i < m_indexes.size(); i++) {
        const auto cell = IndexCell::create(
            this, &m_indexes[i],
            [this, i] {
                m_indexes.erase(m_indexes.begin() + i);
                this->createList();
            },
            CCSize{this->getPopupSize().width - s_padding * 2, 35.f});
        cell->setAnchorPoint({0.f, 0.f});
        m_list->m_contentLayer->addChild(cell);
    }
    const auto menu = CCMenu::create();
    menu->setContentSize({0.f, 36.f});
    m_list->m_contentLayer->addChild(menu);
    m_list->m_contentLayer->setLayout(SimpleColumnLayout::create()
                                          ->setMainAxisDirection(AxisDirection::TopToBottom)
                                          ->setMainAxisAlignment(MainAxisAlignment::Start)
                                          ->setMainAxisScaling(AxisScaling::Grow)
                                          ->setGap(s_padding / 2));

    this->m_mainLayer->addChild(m_list);
    handleTouchPriority(this);
}

}  // namespace jukebox
